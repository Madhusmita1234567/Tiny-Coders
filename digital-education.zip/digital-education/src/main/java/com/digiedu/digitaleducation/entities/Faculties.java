package com.digiedu.digitaleducation.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Faculties {
    @Id
    String facultyId;
    String name;
    String dept;

    public Faculties(String facultyId, String name, String dept) {
        this.facultyId = facultyId;
        this.name = name;
        this.dept = dept;
    }

    public Faculties() {
    }

    public String getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(String facultyId) {
        this.facultyId = facultyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }
}
