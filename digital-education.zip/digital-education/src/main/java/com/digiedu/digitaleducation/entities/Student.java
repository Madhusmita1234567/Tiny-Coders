package com.digiedu.digitaleducation.entities;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {
    @Id
    String rollNo;
    String name;
    String branch;
    String section;
    String currentYear;

    public Student() {
    }

    public Student(String rollNo, String name, String branch, String section, String currentYear) {
        this.rollNo = rollNo;
        this.name = name;
        this.branch = branch;
        this.section = section;
        this.currentYear = currentYear;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getCurrentYear() {
        return currentYear;
    }

    public void setCurrentYear(String currentYear) {
        this.currentYear = currentYear;
    }
}
