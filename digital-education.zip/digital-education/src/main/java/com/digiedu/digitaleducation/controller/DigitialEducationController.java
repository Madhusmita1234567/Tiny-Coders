package com.digiedu.digitaleducation.controller;

import com.digiedu.digitaleducation.entities.Faculties;
import com.digiedu.digitaleducation.entities.Student;
import com.digiedu.digitaleducation.repo.FacultyRepo;
import com.digiedu.digitaleducation.repo.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DigitialEducationController {

    @Autowired
    private StudentRepo studentRepo;
    @Autowired
    private FacultyRepo facultyRepo;

    @PostMapping("/student")
    public ResponseEntity<?> Student(@RequestBody Student student){
         return new ResponseEntity(studentRepo.save(student), HttpStatus.OK);
    }
    @PostMapping("/faculties")
    public ResponseEntity<?> Faculties(@RequestBody Faculties faculties){
        return new ResponseEntity(facultyRepo.save(faculties), HttpStatus.OK);
    }

    @GetMapping("/students")
    public List<Student> Students(){
        return (List<Student>) studentRepo.findAll();
    }

    @GetMapping("/faculties")
    public List<Faculties> faculties(){
        return (List<Faculties>) facultyRepo.findAll();
    }


}
