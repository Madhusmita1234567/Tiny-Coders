package com.digiedu.digitaleducation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalEducationApplicationTests {

	@Test
	void contextLoads() {
	}

}
